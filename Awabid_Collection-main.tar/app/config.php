<?php

$host='localhost';
$username='root';
$password='';
$dbName='awabid._.collection';

$conn=mysqli_connect($host,$username,$password,$dbName);



?>